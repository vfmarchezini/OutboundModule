//Dev Def Vars

var connTimeout;

//vars from cfg File
var configJS;
var conTimeoutCfg;
var conTimeoutResCfg;
var autoLoginCFGtest;
var autoLoginUser;
var autoLoginPass;
var notReadyReasons;

var passFromOlosLogin;

var callVars ={};
var campVars={};

//Olos vars

var addrs;

$(window).on( "load", function() {
	$.getJSON("config.json")
		.always(function(jsonCfg)
    {
	  configJS = jsonCfg; 
      addrs = {
				wsAgentCmd: configJS.GagdetSettings.wsAgentCmd,
			  wsAgentEvt: configJS.GagdetSettings.wsAgentEvt,
			  wsMailingCmd: configJS.GagdetSettings.wsMailingCmd,  
			  wsAgentConfigCmd: configJS.GagdetSettings.wsAgentConfigCmd
   		};
      conTimeoutCfg = configJS.GagdetSettings.connection_timeout;
      conTimeoutResCfg = configJS.GagdetSettings.connection_timeout_reset;
      autoLoginCFGtest = configJS.GagdetSettings.auto_login_test;
      autoLoginUser = configJS.GagdetSettings.auto_login_params[0];
	  autoLoginPass = configJS.GagdetSettings.auto_login_params[1];
	  
		
	  for(let i in configJS.CallDataSettings)
	  {
		  callVars[i] = configJS.CallDataSettings[i];
	  }

	  for(let i in configJS.CampaignDataSettings)
	  {
		  campVars[i] = configJS.CampaignDataSettings[i];
	  }
     		
		if(autoLoginCFGtest == true)
		{
			$("#inputUser").val(autoLoginUser.toString());
			$("#inputPass").val(autoLoginPass.toString());
		}
		else
		{ 
		let searchParams = new URLSearchParams(window.location.search.substring(1));
		if(searchParams.has('user') && searchParams.has('pass'))
		{
			$("#inputUser").val(searchParams.get('user'));
			$("#inputPass").val(searchParams.get('pass'));
			loginRequest();
		}
		}
	})
});


//OLOS EVENTS
Olos.agentCommand.on('agentAuthentication', function(agentId) {
	$("#agentId").val("ID de Agente: " + agentId.toString());
});

Olos.agentCommand.on('passcode', function(passcode) {
	console.log(passcode);
	$('#inputPassOlos').val("Senha Softphone: " +passcode.toString());
	passFromOlosLogin = passcode.toString();
	clearTimeout(connTimeout);
});

Olos.agentCommand.on('loginccm', function(obj) {
      console.log("CCM Login");
});

Olos.agentCommand.on('logincampaign', function(obj) {
	console.log("Campaign Login");
	Olos.agentCommand.listDispositions(obj.campaignId);
	Olos.agentCommand.listReasons();

  $("#btnCont").removeClass("invisible");
  $("#btnCont").addClass("visible");
  $("#loadspinner").detach();
  $('link[src="css/signin"]').remove();

  localStorage.setItem("username", $("#inputUser").val());

  toogleLogin();
});



Olos.agentCommand.on('listDispositions', function(obj) {
	for (let i in obj)
  {
  	$("<option value="+ i + " id="+obj[i].dispositionId+" >"+ obj[i].description +"</option>").appendTo("#inputGroupSelect");
   }
}); 

Olos.agentCommand.on('listReasons', function(obj)
{
	for(let i in obj)
	{
		$("<a class=\"dropdown-item\" href=\"#\" id="+ obj[i].reasonId +" onclick=\"changeAvailability('"+obj[i].description+"', "+ obj[i].reasonId +")\">"+ obj[i].description +"</a>").appendTo("#divDropDown");
	}
});

Olos.agentCommand.on('loginccmfail', function(obj) {
	
  $("#error").html('N�o foi poss�vel realizar o login. Por favor entre em contato com o administrador');
  setTimeout(function reloadPage() {
  	location.reload();
  },conTimeoutResCfg);
});

      //evento que indica falha no login da campanha
Olos.agentCommand.on('logincampaignfail', function(obj) {
      // o par�metro obj retorna as propriedades abaixo
      // {"agentId":108,"campaignId":85,"campaignName":"TesteAtivo","campaignCode":""}
	$("#error").html('N�o foi poss�vel realizar o login. Por favor entre em contato com o administrador');
	setTimeout(function reloadPage() {
  	location.reload();
  },conTimeoutResCfg);
}); 

Olos.agentCommand.on('logoutcampaign', function(obj) {  
	location.reload();
});  
     
Olos.agentCommand.on('logoutccm', function(obj) {
	location.reload();
});  
     
    //evento que indica a falha no logout da campanha
Olos.agentCommand.on('logoutcampaignfail', function(obj) {  // o par�metro obj retorna as propriedades abaixo  // {"agentId":108,"campaignId":2}
  console.log("Logout Failed : Campaign");
	location.reload();
});  
     
    //evento que indica a falha no logout da plataforma  
Olos.agentCommand.on('logoutccmfail', function(obj) {  // o par�metro obj retorna as propriedades abaixo  // {"agentId":108,"campaignId":0}
	console.log("Logout Failed CCM");  
  location.reload();
}); 

Olos.agentCommand.on('changestatus', function(obj) {
	var status = obj.agentStatusId.trim();
	
	switch (status) {
		case notReadyReasons.Talking.value:
			showAgentStatus(notReadyReasons.Talking.description);
			toggleAvailWithCall(true);
			break;
		case notReadyReasons.TalkingWithEnding.value:
			showAgentStatus(notReadyReasons.TalkingWithEnding.description);
			break;
		case notReadyReasons.TalkingWithPause.value:
			showAgentStatus(notReadyReasons.TalkingWithPause.description);
			break;
		case notReadyReasons.Pause.value:
			showAgentStatus(notReadyReasons.Pause.description);
			break;
		case notReadyReasons.Idle.value:
			showAgentStatus(notReadyReasons.Idle.description);
			toggleAvailWithCall(false);
			break;
		case notReadyReasons.Ending.value:
			showAgentStatus(notReadyReasons.Ending.description);
			break;
		case notReadyReasons.Wrap.value:
			showAgentStatus(notReadyReasons.Wrap.description);
			break;
		case notReadyReasons.WrapWithEnding.value:
			showAgentStatus(notReadyReasons.WrapWithEnding.description);
			break;
		case notReadyReasons.WrapWithPause.value:
			showAgentStatus(notReadyReasons.WrapWithPause.description);
			break;
		default:
			showAgentStatus("N�o foi poss�vel recuperar o status");
			break;
		}
});

Olos.agentCommand.on('screenpop', function(obj)
{
	$("#btnRelease").prop("disabled", false);

	$("#call_data_div").removeClass("invisible");
	$("#call_data_div").addClass("visible");
	$("#camp_data_div").removeClass("invisible");
	$("#camp_data_div").addClass("visible");

	for(let i in callVars)
	{
		$("<p class=\"card-text\"> <strong>"+callVars[i].callVarLabel+":</strong> "+obj[callVars[i].cVarOlosKey]+" </p>").appendTo("#call_id");
	}

	for(let i in campVars)
	{
		$("<p class=\"card-text\"> <strong>"+campVars[i].campVarLabel+":</strong> "+$(obj.campaignData).find().prevObject[campVars[i].cVarPosOnXML].innerHTML+" </p>").appendTo("#cust_name");
	}

});

//MODULE FUNCTIONS

$('#btnLogin').on('click', function (e) {
	loginRequest();
});

function loginRequest()
{
	Olos.connect(addrs); 
	Olos.setLogger(0, 'INFO');

	Olos.agentCommand.agentAuthentication($("#inputUser").val(),$("#inputPass").val());

  $("#loadspinner").removeClass("invisible");
  $("#loadspinner").addClass("visible");
  $("#btnLogin").prop('disabled',true);
  notReadyReasons = Olos.agentCommand.getListStatusAgent();
  connTimeout = setTimeout(connectionCheck, conTimeoutCfg);
}

$('#btnLogout').on('click', function (e) {
	localStorage.removeItem("username");
  Olos.agentCommand.agentLogout();
});

$("#btnSendDisposition").on('click', function(e)
{
	var dispId = $("#inputGroupSelect :selected").prop("id");
	console.log(dispId);
	$("#wrapModal").modal("hide");
	Olos.agentCommand.dispositionCall(parseInt(dispId));
	$("#call_data_div").removeClass("visible");
	$("#call_data_div").addClass("invisible");
	$("#camp_data_div").removeClass("visible");
	$("#camp_data_div").addClass("invisible");
	$("#btnRelease").prop("disabled", true);
	$(".card-text").remove();
 });

function connectionCheck()
{
	$("#error").html('N�o foi poss�vel conectar ao servidor! Recarregando...');
  	setTimeout(function reloadPage() {
  		location.reload();
  	},conTimeoutResCfg);
}

 function toogleLogin()
 {
   $("body").removeClass("text-center");
   $("#login_form").remove();
   $("#agent_control").show();
   $("body").css("align-items", "normal");
 }

function showAgentStatus(agentStatus)
{
	$("#status_agent").html(agentStatus);
}

function toggleAvailWithCall(toggle)
{
	if(toggle){
		$('#btnReadyToggle').removeClass('btn btn-success');
		$('#btnReadyToggle').addClass('btn btn-warning');
		$('#status_agent').removeClass('btn-light');
		$('#status_agent').addClass('btn-warning');
	}
	else{
		$('#btnReadyToggle').removeClass('btn btn-warning');
		$('#btnReadyToggle').addClass('btn btn-success');
		$('#status_agent').removeClass('btn-warning');
		$('#status_agent').addClass('btn-success');
	}
}
 
function changeAvailability(btnContent, rsId)
{
	if(btnContent == 'avail'){
		Olos.agentCommand.agentIdleRequest();
	  $('#btnReadyToggle').html('Pronto');
	  $('#btnReadyToggle').removeClass('btn btn-danger');
	  $('#btnReadyToggle').addClass('btn btn-success');
	  $('#status_agent').removeClass('btn-danger');
	  $('#status_agent').addClass('btn-success');
  }
  else{
  	Olos.agentCommand.agentReasonRequest(parseInt(rsId));
  	$('#btnReadyToggle').html(btnContent);
    $('#btnReadyToggle').removeClass('btn btn-success');
	$('#btnReadyToggle').addClass('btn btn-danger');
	$('#status_agent').removeClass('btn-success');
	$('#status_agent').addClass('btn-danger');
  }
}

function olosEvents(objEvent) {}; 