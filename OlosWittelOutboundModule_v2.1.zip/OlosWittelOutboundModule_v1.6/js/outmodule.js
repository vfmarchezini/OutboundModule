//Dev Def Vars

var connTimeout = null;

//vars from cfg File
var configJS =  {};
var conTimeoutCfg = null; // CFG file timeout for use with connTimeout variable
var conTimeoutResCfg = null;
var autoLoginCFGtest = null;
var autoLoginUser = null;
var autoLoginPass = null;
var notReadyReasons;
    
//Olos vars

var Olos = Olos ||{};
var addrs = null; 

$(window).on( "load", function() {
	$.getJSON("config.json")
		.always(function(jsonCfg)
    {
			configJS = jsonCfg; 
      addrs = {
				wsAgentCmd: configJS.GagdetSettings.wsAgentCmd,
			  wsAgentEvt: configJS.GagdetSettings.wsAgentEvt,
			  wsMailingCmd: configJS.GagdetSettings.wsMailingCmd,  
			  wsAgentConfigCmd: configJS.GagdetSettings.wsAgentConfigCmd
   		};
      conTimeoutCfg = configJS.GagdetSettings.connection_timeout;
      conTimeoutResCfg = configJS.GagdetSettings.connection_timeout_reset;
      autoLoginCFGtest = configJS.GagdetSettings.auto_login_test;
      autoLoginUser = configJS.GagdetSettings.auto_login_params[0];
      autoLoginPass = configJS.GagdetSettings.auto_login_params[1];
    if(autoLoginCFGtest == true)
      {
  	  	$("#inputUser").val(autoLoginUser.toString());
  	  	$("#inputPass").val(autoLoginPass.toString());
      }
    })
});

$('#btnLogin').on('click', function (e) {

	Olos.connect(addrs); 
  Olos.setLogger(0, 'INFO');
      	
  if(autoLoginCFGtest == true)
  {	
  	Olos.agentCommand.agentAuthentication(autoLoginUser,autoLoginPass);
  }
  else
  {
  	Olos.agentCommand.agentAuthentication($("#inputUser").val(),$("#inputPass").val());
  }

  $("#loadspinner").removeClass("invisible");
  $("#loadspinner").addClass("visible");
  $("#btnLogin").prop('disabled',true);
  notReadyReasons = Olos.agentCommand.getListStatusAgent();
  connTimeout = setTimeout(connectionCheck, conTimeoutCfg);
});

$('#btnLogout').on('click', function (e) {
	localStorage.removeItem("username");
  Olos.agentCommand.agentLogout();
});

function connectionCheck()
{
	$("#error").html('Não foi possível conectar ao servidor! Recarregando...');
  setTimeout(function reloadPage() {
  	location.reload(true);
  },conTimeoutResCfg);
}

Olos.agentCommand.on('agentAuthentication', function(agentId) {
	$("#agentId").val("ID de Agente: " + agentId.toString());
});

Olos.agentCommand.on('passcode', function(passcode) {
	$('#inputPassOlos').val("Senha Softphone: " +passcode.toString());
	clearTimeout(connTimeout);
});

Olos.agentCommand.on('loginccm', function(obj) {
      // o parâmetro obj retorna as propriedades abaixo
      // {"agentId":108,"agentName":"User 2"}
});

Olos.agentCommand.on('logincampaign', function(obj) {
	Olos.agentCommand.listDispositions(obj.campaignId);
	Olos.agentCommand.listReasons();

  $("#btnCont").removeClass("invisible");
  $("#btnCont").addClass("visible");
  $("#loadspinner").detach();

  localStorage.setItem("username", $("#inputUser").val());

  toogleLogin();
});

function toogleLogin()
{
  $("body").removeClass("text-center");
  $("#login_form").remove();
  $("#agent_control").show();
  $("body").css("align-items", "normal");
}

Olos.agentCommand.on('listDispositions', function(obj) {
	for (let i in obj)
  {
  	$("<option value="+ i + " id="+obj[i].dispositionId+" >"+ obj[i].description +"</option>").appendTo("#inputGroupSelect");
   }
}); 

Olos.agentCommand.on('listReasons', function(obj)
{
	for(let i in obj)
	{
		$("<a class=\"dropdown-item\" href=\"#\" id="+ obj[i].reasonId +" onclick=\"changeAvailability('"+obj[i].description+"', "+ obj[i].reasonId +")\">"+ obj[i].description +"</a>").appendTo("#divDropDown");
	}
});

Olos.agentCommand.on('loginccmfail', function(obj) {
	// o parâmetro obj retorna as propriedades abaixo
  // {"agentId":108,"agentName":"User 2"}
  $("#error").html('Não foi possível realizar o login. Por favor entre em contato com o administrador');
  setTimeout(function reloadPage() {
  	location.reload(true);
  },conTimeoutResCfg);
});

      //evento que indica falha no login da campanha
Olos.agentCommand.on('logincampaignfail', function(obj) {
      // o parâmetro obj retorna as propriedades abaixo
      // {"agentId":108,"campaignId":85,"campaignName":"TesteAtivo","campaignCode":""}
	$("#error").html('Não foi possível realizar o login. Por favor entre em contato com o administrador');
	setTimeout(function reloadPage() {
  	location.reload(true);
  },conTimeoutResCfg);
}); 

Olos.agentCommand.on('logoutcampaign', function(obj) {  
	location.reload(true);
});  
     
Olos.agentCommand.on('logoutccm', function(obj) {
	location.reload(true);
});  
     
    //evento que indica a falha no logout da campanha
Olos.agentCommand.on('logoutcampaignfail', function(obj) {  // o parâmetro obj retorna as propriedades abaixo  // {"agentId":108,"campaignId":2}
  console.log("Logout Failed");
	location.reload(true);
});  
     
    //evento que indica a falha no logout da plataforma  
Olos.agentCommand.on('logoutccmfail', function(obj) {  // o parâmetro obj retorna as propriedades abaixo  // {"agentId":108,"campaignId":0}
	console.log("Logout Failed");  
  location.reload(true);
}); 

Olos.agentCommand.on('changestatus', function(obj) {
	var status = obj.agentStatusId.trim();
	/*console.log(status);
	console.log(notReadyReasons.Talking.value);
	console.log(notReadyReasons.Talking.description);
	console.log(notReadyReasons.Pause.value);
	console.log(notReadyReasons.Pause.description);*/
	
	switch (status) {
		case notReadyReasons.Talking.value:
			showAgentStatus(notReadyReasons.Talking.description);
			break;
		case notReadyReasons.TalkingWithEnding.value:
			showAgentStatus(notReadyReasons.TalkingWithEnding.description);
			break;
		case notReadyReasons.TalkingWithPause.value:
			showAgentStatus(notReadyReasons.TalkingWithPause.description);
			break;
		case notReadyReasons.Pause.value:
			showAgentStatus(notReadyReasons.Pause.description);
			break;
		case notReadyReasons.Idle.value:
			showAgentStatus(notReadyReasons.Idle.description);
			break;
		case notReadyReasons.Ending.value:
			showAgentStatus(notReadyReasons.Ending.description);
			break;
		case notReadyReasons.Wrap.value:
			showAgentStatus(notReadyReasons.Wrap.description);
			break;
		case notReadyReasons.WrapWithEnding.value:
			showAgentStatus(notReadyReasons.WrapWithEnding.description);
			break;
		case notReadyReasons.WrapWithPause.value:
			showAgentStatus(notReadyReasons.WrapWithPause.description);
			break;
		default:
			showAgentStatus("Não foi possível recuperar o status");
			break;
		}
});

Olos.agentCommand.on('screenpop', function(obj)
{
	//TO DO Colocar legenda
	//TO DO Colocar tratamento no desligamento da chamada

	$("#call_id").html(obj.callId);

	for(let i in obj)
	{
		$("<p class=\"card-text\"> "+obj[i]+" </p>").appendTo("#call_id");
	}
});

$("#btnSendDisposition").on('click', function(e)
{
	var dispId = $("#inputGroupSelect :selected").prop("id");
	$("#wrapModal").modal("hide");
  Olos.agentCommand.dispositionCall(parseInt(dispId));
 });

function showAgentStatus(agentStatus)
{
	$("#status_agent").html(agentStatus);
}
 
function changeAvailability(btnContent, rsId)
{
	if(btnContent == 'avail'){
		Olos.agentCommand.agentIdleRequest();
	  $('#btnReadyToggle').html('Pronto');
	  $('#btnReadyToggle').removeClass('btn btn-danger');
	  $('#btnReadyToggle').addClass('btn btn-success');
  }
  else{
	  console.log(btnContent);
	  console.log(rsId);
  	Olos.agentCommand.agentReasonRequest(parseInt(rsId));
  	$('#btnReadyToggle').html(btnContent);
    $('#btnReadyToggle').removeClass('btn btn-success');
    $('#btnReadyToggle').addClass('btn btn-danger');
  }
}

function olosEvents(objEvent) {}; 